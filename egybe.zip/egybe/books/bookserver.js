import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import 'dotenv/config';
import mysql from 'mysql2/promise';
import cors from 'cors'

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const poolConfig = {
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
};

const pool = mysql.createPool(poolConfig)

const app = express();

app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 8000;

app.get('/', (req,res) => {
    res.send('Welcome to the Book Server')
})

app.get('/api/books', async (req,res) => {
    try {
        const [sorok] = await pool.query('SELECT * FROM books');
        res.json(sorok);
    }
    catch (error) {
        console.error('Error fetching books:', error);
        res.status(500).json({error : "Internal server error!"})
    }
})

app.get('/api/books/:id', async (req, res) => {
    const id = Number.parseInt(req.params.id, 10);

    try {
        const [sorok] = await pool.query('SELECT * FROM books WHERE id = ?', [id]);

        if (sorok.length === 0) {
            return res.status(404).json({ error: 'Book not found' });
        }

        res.json(sorok[0]);
    } catch (error) {
        console.error('Error fetching book:', error);
        res.status(500).json({ error: 'Internal server error!' });
    }
});

app.post('/api/books', async (req, res) => {
    const { title, author, pages, available } = req.body;

    if (!title || !author) {
        return res.status(400).json({ error: 'Title and author are required' });
    }

    try {
        const [result] = await pool.query(
            'INSERT INTO books (title, author, pages, available) VALUES (?, ?, ?, ?)',
            [title, author, pages, available ?? true]
        );

        res.status(201).json({
            id: result.insertId,
            title,
            author,
            pages,
            available: available ?? true,
        });
    } catch (error) {
        console.error('Error creating book:', error);
        res.status(500).json({ error: 'Internal server error!' });
    }
});

app.put('/api/books/:id', async (req, res) => {
    const id = Number.parseInt(req.params.id, 10);
    const { title, author, pages, available } = req.body;

    try {
        const [result] = await pool.query(
            'UPDATE books SET title = ?, author = ?, pages = ?, available = ? WHERE id = ?',
            [title, author, pages, available, id]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Book not found' });
        }

        res.status(200).json({ id, title, author, pages, available });
    } catch (error) {
        console.error('Error updating book:', error);
        res.status(500).json({ error: 'Internal server error!' });
    }
});

app.delete('/api/books/:id', async (req, res) => {
    const id = Number.parseInt(req.params.id, 10);

    try {
        const [result] = await pool.query('DELETE FROM books WHERE id = ?', [id]);

        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Book not found' });
        }

        res.status(200).json({ message: 'Book deleted successfully' });
    } catch (error) {
        console.error('Error deleting book:', error);
        res.status(500).json({ error: 'Internal server error!' });
    }
});





app.listen(PORT, () => {
    console.log(`bookserver is running on port ${PORT}`)
})