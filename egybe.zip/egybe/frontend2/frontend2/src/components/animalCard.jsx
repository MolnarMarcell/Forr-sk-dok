export default function AnimalCard({data: {name, species, image}})
{
    let h1Style = {
        color: "brown",
        fontSize: "24px",
        fontWeight: "bold"
    }

    let pStyle = {
        color: "white",
        fontsize: "18px"
    }

    return (
        <div style={{border: "solid 2px black", backgroundcolor: "red", padding: "10px", borderRadius : "9px"}}>
        <h1 style={h1Style}>Állat</h1>
        <p style={pStyle}>{name}</p>
        <p>{species}</p>
        <img src={image} alt={name} style={{width: "300px", height: "auto", borderRadius: "9px"}}></img>
        </div>


    )

}