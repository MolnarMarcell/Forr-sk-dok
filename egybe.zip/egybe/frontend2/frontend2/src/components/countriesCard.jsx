export default function CountriesCard({data: {name, capital, continent, population, currency, flag, isVisited}})
{
    let h1Style = {
        color: "black",
        fontWeight: "bold",
    }

    return (
        <div id="boxtarto" style={{border: "solid 2px black", backgroundColor: "lightblue", padding: "10px", margin: "5px", borderRadius : "9px", color: "black"}}>
            <h1 style={h1Style}>{name}</h1>
            <h2>Főváros: {capital}</h2>
            <p>Kontinens: {continent}</p>
            <p>Lakosság: {population}</p>
            <p>Fizető eszköz: {currency}</p>
            <img style={{border: "solid 6px rgba(100, 200, 200, 255)", borderRadius: "9px", boxShadow: "0px 0px 10px rgba(0,0,0, 0.3)"}} src={flag} alt={name}/>
            <p>{isVisited ? "Már látogatták!" : "Még nem látogatták!"}</p>
        </div>
    )
}