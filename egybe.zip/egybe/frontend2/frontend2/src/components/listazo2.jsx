import { useEffect, useState } from "react";
import axios from 'axios';

export default function Listazo2() {
    const [data, setData] = useState([]);

    useEffect(() => {
        console.log('useEffect called!');
        async function fetchDataAxios() {
            try {
                const response = await axios.get('http://localhost:8000/api/books');
                setData(response.data);
            } catch (error) {
                console.error('Error fetching books', error);
            }
        }





        // async function fetchData() {
        //     try {
        //         const response = await fetch("http://localhost:8000/api/books");

        //         if (!response.ok) {
        //             throw new Error(`Hálózati hiba: ${response.status}`);
        //         }

        //         const jsonData = await response.json();
        //         setData(jsonData);
        //     } catch (error) {
        //         console.error("Error fetching books", error);
        //     }
        // }

        fetchDataAxios();
    }, []);

    return (
        <div>
            {data.map((book) => (
                <p key={book.id}>{book.title}</p>
            ))}
        </div>
    );
}