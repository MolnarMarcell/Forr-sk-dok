import { useState, useEffect, useEffectEvent } from "react";
import { preconnect } from "react-dom";

export default function Szamlalo() {
    const [counter, setCounter] = useState(10)
//esemény kezelő a komponens betöltésekor
    useEffect(() => {
        setCounter(999);
    })

    // useEffect(() => {
    //     const interval = setInterval(() => {
    //         setCounter(prevCounter => prevCounter + 1);        
    //     }, 1000);
    //     return () => clearInterval(interval);
    // }, []);

    return (
        <div style={{border: "solid 2px black", margin: "20px", padding: "20px", backgroundColor: "lightslategrey", color: "white"}}>
            <h1>Számláló</h1>
            <p>{counter}</p>
            <button onClick={() => setCounter(counter +1)}>Növelés</button>
            <button onClick={() => setCounter(counter -1)}>Csökkentés</button>
            <button onClick={() => setCounter(0)}>Nullázás</button>
        </div>
    )
}