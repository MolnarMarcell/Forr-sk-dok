import { useEffect, useState } from "react";

export default function Listazo() {
    const [data, setData] = useState([]);

    useEffect(() => {
        async function fetchdata() {
            try {
                const response = await fetch('http://localhost:8000/api/books')
                if (!response.ok) {
                    throw new Error('Hálozati hiba:' + response.status);
                }
                const jsonData = await response.json();
                setData(jsonData);
            } catch (error)
            {
                console.error('Hiba az adatok lekérésekor!:', error)
            }
        }
        fetchdata();
    }, []);

    return (
        <div>
            <h1>listázó</h1>
            <ul>
                {data.map(item => (
                    <li key={item.id}>
                        <h2>{item.title}</h2>
                        <p>{item.author}</p>
                        <h2>{item.pages}</h2>
                    </li>
                ))}
            </ul>
        </div>
    );
}