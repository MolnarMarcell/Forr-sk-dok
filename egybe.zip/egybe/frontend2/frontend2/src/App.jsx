// import './App.css'
import AnimalCard from './components/animalCard'
import countries from './assets/countries.json'
import CountriesCard from './components/countriesCard'
import Szamlalo from './components/Szamlalo'
import Listazo from './components/Listazo'
import Listazo2 from './components/listazo2'

function App() {

  // let animals = [
  //   {
  //    id: 1,
  //     name: "Brumi",
  //     species: "Barna medve",
  //     image: "https://cdn.shopify.com/s/files/1/1070/8814/files/Screenshot_2025-09-19_at_7.05.37_pm_480x480.png?v=1758272801"
  //   },
  //   {
  //     id: 2,
  //     name: "balu",
  //     species: "zsiráf",
  //     image: "https://cdn.shopify.com/s/files/1/1070/8814/files/Screenshot_2025-09-19_at_7.05.37_pm_480x480.png?v=1758272801"
  //     }
  //   ]
  return (

    <div className='App'>
        <Listazo/>
      {/* <div className="szamlalo"> */}
        {/* <Szamlalo/>
        <Szamlalo/> */}
      {/* </div> */}
      {/* <h1>Országok</h1>
      {countries.map(country => (
          <CountriesCard key={country.id || country.name} data={country}/>
        ))} */}
      </div>
  )
}

export default App
